import './App.css';
import React, {useState} from 'react';
import axios from 'axios';
import {TextField, Grid, AppBar, ToolBar, Button} from "@mui/material"

function App() {

  const [file, setFile] = useState();
  const [uploadedFile, setUploadedFile] = useState();
  const [error, setError] = useState();
  const [inputQuery, setInputQuery] = useState();
  const [response, setResponse] = useState();


  function handleChange(event) {setFile(event.target.files[0]);}

  function handleQueryChange(e) {setInputQuery(e.target.value)}

  function getQueryAnswer()
  {
    console.log(inputQuery);
    const url = 'http://127.0.0.1:5000/query';
    axios.get(url,
      {
        params:
        {
          inputQuery: inputQuery,
        }
      }).then((response)=>{
        setResponse(response.data['result'])
      }).catch((e)=>{
        console.log(e)
      })
  }

  function getGPTModelAnswer()
  {
    const url = 'http://127.0.0.1:5000/queryGpt';
    axios.get(url,
      {
        params:
        {
          inputQuery: inputQuery,
        }
      }).then((response)=>{
        setResponse(response.data['result'])
      }).catch((e)=>{
        console.log(e)
      })
  }
  
  function handleSubmit(event) {
    event.preventDefault();
    const url = 'http://127.0.0.1:5000/upload';
    const formData = new FormData();
    formData.append('file', file);
    formData.append('fileName', file.name);
    const config = {
      headers: {
        'content-type': 'multipart/form-data',
      },
    };
    axios.post(url, formData, config)
      .then((response) => {
        console.log(response);
        setUploadedFile(response.data)
      })
      .catch((error) => {
        console.error("Error uploading file: ", error);
        setError(error);
      });
  }

  return (
    <div className="App">
        <form onSubmit={handleSubmit}>
          <h1>Upload your File Here</h1>
          <input type="file" onChange={handleChange}/>
          <Button type="submit">Upload</Button>
        </form>
        {uploadedFile}
        {error && <p>Error uploading file: {error.message}</p>}
        <br></br>
        <div>Enter Query: 
        <TextField
        fullWidth
        multiline={true}
        rows={2}
        width={100}
        value={inputQuery}
        onChange={(e)=>handleQueryChange(e)}
        ></TextField>
        <Button onClick={getQueryAnswer}>Query Free GPT</Button>
        <Button onClick={getGPTModelAnswer}>Query Msft GPT</Button>
        </div>
        <br></br>
        <br></br>
        <div>
          Result:
          <TextField
          fullWidth
        multiline={true}
        rows={5}
        width={100}
        value={response}
        ></TextField>
        </div>
    </div>
  );
}

export default App;